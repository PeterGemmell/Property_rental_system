package com.example.rentalsystem.rentalservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RentalserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(RentalserviceApplication.class, args);
	}

}
