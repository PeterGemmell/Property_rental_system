package com.example.rentalsystem.rentalservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RentalserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
